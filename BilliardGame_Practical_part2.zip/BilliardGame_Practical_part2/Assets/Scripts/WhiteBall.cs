﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WhiteBall : MonoBehaviour
{

Rigidbody2d rigidbody2;

Random.InitState(12345);

float X = Random.Range(-1, 1)
float y = Random.Range(15,20)

if(Input.GetButtonDown("Fire1"){
	rigidbody2.velocity = new Vector2(x,y)
}




    // Start is called before the first frame update
    void Start()
    {
        rigidbody2 = GetComponent<CircleCollider2D>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
